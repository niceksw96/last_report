from django.apps import AppConfig


class MyscheduleConfig(AppConfig):
    name = 'myschedule'
