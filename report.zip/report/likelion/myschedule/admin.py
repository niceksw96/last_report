from django.contrib import admin
from .models import Schedule

# Register your models here.
admin.site.register(Schedule)